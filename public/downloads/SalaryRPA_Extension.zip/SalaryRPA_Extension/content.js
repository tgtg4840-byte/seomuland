(() => {
  "use strict";

  if (window.__salaryRpaLoaded) {
    if (typeof window.__salaryRpaShowPanel === "function") {
      window.__salaryRpaShowPanel();
    }
    return;
  }
  window.__salaryRpaLoaded = true;

  const HOST_ID = "__salary_rpa_panel_host__";
  const HIGHLIGHT_CLASS = "__salary_rpa_highlight__";
  const RESERVED_COLUMNS = new Set(["이름"]);

  const state = {
    csvRows: [],
    headers: [],
    fileName: "",
    coreMap: {
      nameInput: "",
      confirmButton: "",
      copyButton: "",
      saveButton: ""
    },
    salaryMap: {},
    mappingTarget: null,
    running: false,
    stopRequested: false,
    pauseResolver: null,
    pendingItem: null
  };

  let host = null;
  let shadow = null;

  function createPanel() {
    host = document.getElementById(HOST_ID);
    if (host) {
      host.style.display = "block";
      return;
    }

    host = document.createElement("div");
    host.id = HOST_ID;
    host.style.position = "fixed";
    host.style.top = "12px";
    host.style.right = "12px";
    host.style.zIndex = "2147483647";
    host.style.width = "410px";
    host.style.maxHeight = "calc(100vh - 24px)";
    host.style.fontFamily = '"Malgun Gothic", Arial, sans-serif';
    document.documentElement.appendChild(host);

    shadow = host.attachShadow({mode: "open"});
    shadow.innerHTML = `
      <style>
        *{box-sizing:border-box}
        .panel{background:#fff;border:1px solid #cfd9e2;border-radius:12px;
          box-shadow:0 14px 38px rgba(0,0,0,.22);overflow:hidden;color:#1d2935}
        .header{display:flex;align-items:center;justify-content:space-between;
          padding:11px 13px;background:#174f80;color:#fff}
        .header strong{font-size:15px}.close{border:0;background:transparent;color:#fff;
          font-size:20px;cursor:pointer;line-height:1}
        .body{padding:11px;max-height:calc(100vh - 78px);overflow:auto;background:#f5f8fa}
        .section{background:#fff;border:1px solid #d8e1e9;border-radius:9px;
          margin-bottom:9px;overflow:hidden}
        .title{padding:9px 10px;background:#f8fafc;border-bottom:1px solid #e0e7ed;
          font-size:12px;font-weight:700}
        .content{padding:10px}.row{display:flex;gap:7px;align-items:center;flex-wrap:wrap}
        button{font:inherit;border:1px solid #c9d5df;background:#fff;border-radius:7px;
          padding:7px 9px;font-size:12px;font-weight:700;cursor:pointer}
        button.primary{background:#246aa8;color:#fff;border-color:#246aa8}
        button.success{background:#18794e;color:#fff;border-color:#18794e}
        button.warn{background:#fff7e9;color:#9a6200;border-color:#e5c58f}
        button.danger{background:#fff1ef;color:#b42318;border-color:#efc1bb}
        button:disabled{opacity:.45;cursor:not-allowed}
        input[type=file]{width:100%;font-size:12px}
        .meta{font-size:11px;color:#687684;margin-top:6px}
        table{width:100%;border-collapse:collapse}
        th,td{padding:7px;border-bottom:1px solid #e8edf2;text-align:left;font-size:11px}
        th{background:#f7f9fb;color:#5d6974;position:sticky;top:0}
        .table-wrap{max-height:240px;overflow:auto}
        .mapped{color:#18794e;font-weight:700}.missing{color:#b42318;font-weight:700}
        .log{height:145px;overflow:auto;background:#17211b;color:#d4e7d8;
          border-radius:7px;padding:8px;font:11px/1.55 Consolas,monospace}
        .log div::before{content:"› ";color:#7cc490}
        .log .warn{color:#ffd17a}.log .error{color:#ffaaa4}
        .pause{display:none;padding:9px;border:1px solid #e3bd78;background:#fff8ea;
          border-radius:8px;margin-top:8px}
        .pause.show{display:block}.pause p{font-size:11px;line-height:1.5;margin:0 0 8px}
        .status{font-size:11px;color:#687684;margin-left:auto}
        .guide{font-size:11px;color:#9a6200;font-weight:700;margin-top:7px}
      </style>

      <div class="panel">
        <div class="header">
          <strong>급여입력 RPA</strong>
          <button class="close" id="closePanel" title="닫기">×</button>
        </div>

        <div class="body">
          <section class="section">
            <div class="title">1. CSV 불러오기</div>
            <div class="content">
              <input id="csvFile" type="file" accept=".csv,text/csv">
              <div class="meta" id="csvMeta">CSV 미선택</div>
            </div>
          </section>

          <section class="section">
            <div class="title">2. 입력란·버튼 맵핑</div>
            <div class="table-wrap">
              <table>
                <thead><tr><th>항목</th><th>동작</th><th>상태</th><th></th></tr></thead>
                <tbody id="mappingBody"></tbody>
              </table>
            </div>
            <div class="content">
              <div class="guide" id="mappingGuide">맵핑할 항목의 버튼을 누르십시오.</div>
            </div>
          </section>

          <section class="section">
            <div class="title">3. 실행</div>
            <div class="content">
              <div class="row">
                <button class="success" id="runButton" disabled>자동입력 시작</button>
                <button class="danger" id="stopButton" disabled>중단</button>
                <span class="status" id="runStatus">대기</span>
              </div>

              <div class="pause" id="pauseBox">
                <p id="pauseText"></p>
                <div class="row">
                  <button class="primary" id="mapMissingButton">신규 항목 맵핑</button>
                  <button class="warn" id="manualContinueButton">수기입력 후 계속</button>
                  <button class="danger" id="cancelButton">중단</button>
                </div>
              </div>
            </div>
          </section>

          <section class="section">
            <div class="title">로그</div>
            <div class="content">
              <div class="log" id="logBox"></div>
            </div>
          </section>
        </div>
      </div>
    `;

    bindPanelEvents();
    renderMappings();
    updateButtons();
    log("RPA 패널 준비 완료");
  }

  function $(id) {
    return shadow.getElementById(id);
  }

  function showPanel() {
    createPanel();
    host.style.display = "block";
  }
  window.__salaryRpaShowPanel = showPanel;

  function bindPanelEvents() {
    $("closePanel").addEventListener("click", () => {
      host.style.display = "none";
    });

    $("csvFile").addEventListener("change", event => {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = () => {
        try {
          loadCsv(String(reader.result || ""), file.name);
        } catch (error) {
          alert(error.message);
          log(error.message, "error");
        }
      };
      reader.readAsText(file, "utf-8");
    });

    $("runButton").addEventListener("click", runAutomation);
    $("stopButton").addEventListener("click", () => {
      state.stopRequested = true;
      resolvePause("cancel");
    });

    $("mapMissingButton").addEventListener("click", () => {
      if (!state.pendingItem) return;
      beginMapping({
        kind: "salary",
        key: state.pendingItem.item,
        resumeAfterMapping: true
      });
    });

    $("manualContinueButton").addEventListener("click", () => {
      resolvePause("manual");
    });

    $("cancelButton").addEventListener("click", () => {
      resolvePause("cancel");
    });

    document.addEventListener("click", captureMappedElement, true);
  }

  function parseCsv(text) {
    text = text.replace(/^\uFEFF/, "");
    const matrix = [];
    let row = [];
    let cell = "";
    let quoted = false;

    for (let i = 0; i < text.length; i++) {
      const ch = text[i];

      if (quoted) {
        if (ch === '"' && text[i + 1] === '"') {
          cell += '"';
          i++;
        } else if (ch === '"') {
          quoted = false;
        } else {
          cell += ch;
        }
      } else {
        if (ch === '"') {
          quoted = true;
        } else if (ch === ",") {
          row.push(cell.trim());
          cell = "";
        } else if (ch === "\n") {
          row.push(cell.trim());
          cell = "";
          if (row.some(value => value !== "")) matrix.push(row);
          row = [];
        } else if (ch !== "\r") {
          cell += ch;
        }
      }
    }

    if (cell.length || row.length) {
      row.push(cell.trim());
      if (row.some(value => value !== "")) matrix.push(row);
    }

    return matrix;
  }

  function loadCsv(text, fileName) {
    const matrix = parseCsv(text);
    if (matrix.length < 2) {
      throw new Error("CSV에 입력할 데이터가 없습니다.");
    }

    const headers = matrix[0];
    if (!headers.includes("이름")) {
      throw new Error("CSV에 '이름' 열이 필요합니다.");
    }

    state.headers = headers;
    state.csvRows = matrix.slice(1).map(cells => {
      const row = {};
      headers.forEach((header, index) => {
        row[header] = cells[index] ?? "";
      });
      return row;
    });
    state.fileName = fileName;

    salaryHeaders().forEach(header => {
      if (!(header in state.salaryMap)) {
        state.salaryMap[header] = "";
      }
    });

    $("csvMeta").textContent =
      `${fileName} · ${state.csvRows.length}명 · 급여항목 ${salaryHeaders().length}개`;

    renderMappings();
    updateButtons();
    log(`CSV 불러오기 완료: ${fileName}`);
  }

  function salaryHeaders() {
    return state.headers.filter(header => !RESERVED_COLUMNS.has(header));
  }

  function mappingRows() {
    const rows = [
      {kind: "core", key: "nameInput", label: "이름 입력란", action: "입력",
        selector: state.coreMap.nameInput},
      {kind: "core", key: "confirmButton", label: "확인 버튼", action: "클릭",
        selector: state.coreMap.confirmButton},
      {kind: "core", key: "copyButton", label: "전월자료 복사 버튼", action: "클릭",
        selector: state.coreMap.copyButton},
      {kind: "core", key: "saveButton", label: "저장 버튼", action: "클릭",
        selector: state.coreMap.saveButton}
    ];

    salaryHeaders().forEach(header => {
      rows.push({
        kind: "salary",
        key: header,
        label: header,
        action: "입력",
        selector: state.salaryMap[header] || ""
      });
    });

    return rows;
  }

  function renderMappings() {
    const body = $("mappingBody");
    body.innerHTML = "";

    mappingRows().forEach(item => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${escapeHtml(item.label)}</td>
        <td>${item.action}</td>
        <td class="${item.selector ? "mapped" : "missing"}">
          ${item.selector ? "완료" : "미맵핑"}
        </td>
        <td><button data-kind="${item.kind}" data-key="${escapeHtml(item.key)}">맵핑</button></td>
      `;

      tr.querySelector("button").addEventListener("click", () => {
        beginMapping({
          kind: item.kind,
          key: item.key,
          resumeAfterMapping: false
        });
      });

      body.appendChild(tr);
    });
  }

  function beginMapping(target) {
    state.mappingTarget = target;
    const label = target.kind === "core"
      ? mappingRows().find(item => item.kind === "core" && item.key === target.key)?.label
      : target.key;

    $("mappingGuide").textContent =
      `${label || target.key}: 실제 사이트의 대응 입력란 또는 버튼을 클릭하십시오.`;
    log(`${label || target.key} 맵핑 대기`, "warn");
  }

  function captureMappedElement(event) {
    if (!state.mappingTarget) return;

    const path = event.composedPath ? event.composedPath() : [];
    if (path.includes(host)) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    let element = event.target;
    if (element && typeof element.closest === "function") {
      element = element.closest("input,textarea,select,button,[role='button']") || element;
    }

    const selector = makeSelector(element);
    const target = state.mappingTarget;
    state.mappingTarget = null;

    if (target.kind === "core") {
      state.coreMap[target.key] = selector;
    } else {
      state.salaryMap[target.key] = selector;
    }

    highlight(element);
    $("mappingGuide").textContent = `${target.key} 맵핑 완료`;
    log(`${target.key} → ${selector}`);

    renderMappings();
    updateButtons();

    if (target.resumeAfterMapping) {
      resolvePause("mapped");
    }
  }

  function makeSelector(element) {
    if (!(element instanceof Element)) {
      throw new Error("선택한 화면 요소를 맵핑할 수 없습니다.");
    }

    if (element.id) {
      const candidate = `#${cssEscape(element.id)}`;
      if (document.querySelectorAll(candidate).length === 1) return candidate;
    }

    if (element.getAttribute("name")) {
      const name = element.getAttribute("name");
      const candidate =
        `${element.tagName.toLowerCase()}[name="${escapeAttribute(name)}"]`;
      if (document.querySelectorAll(candidate).length === 1) return candidate;
    }

    const dataAttributes = ["data-pay-item", "data-field", "data-name"];
    for (const attribute of dataAttributes) {
      const value = element.getAttribute(attribute);
      if (value) {
        const candidate = `[${attribute}="${escapeAttribute(value)}"]`;
        if (document.querySelectorAll(candidate).length === 1) return candidate;
      }
    }

    const parts = [];
    let current = element;

    while (current && current.nodeType === Node.ELEMENT_NODE &&
           current !== document.documentElement) {
      let part = current.tagName.toLowerCase();
      const parent = current.parentElement;

      if (parent) {
        const sameTags = Array.from(parent.children)
          .filter(child => child.tagName === current.tagName);
        if (sameTags.length > 1) {
          part += `:nth-of-type(${sameTags.indexOf(current) + 1})`;
        }
      }

      parts.unshift(part);
      const candidate = parts.join(" > ");
      if (document.querySelectorAll(candidate).length === 1) return candidate;
      current = parent;
    }

    return parts.join(" > ");
  }

  function cssEscape(value) {
    if (window.CSS && typeof CSS.escape === "function") return CSS.escape(value);
    return String(value).replace(/([^\w-])/g, "\\$1");
  }

  function escapeAttribute(value) {
    return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;",
      '"': "&quot;", "'": "&#039;"
    }[ch]));
  }

  function highlight(element) {
    if (!(element instanceof Element)) return;
    element.classList.add(HIGHLIGHT_CLASS);

    if (!document.getElementById("__salary_rpa_highlight_style__")) {
      const style = document.createElement("style");
      style.id = "__salary_rpa_highlight_style__";
      style.textContent =
        `.${HIGHLIGHT_CLASS}{outline:4px solid #f0a229!important;outline-offset:2px!important}`;
      document.documentElement.appendChild(style);
    }

    setTimeout(() => element.classList.remove(HIGHLIGHT_CLASS), 800);
  }

  function updateButtons() {
    if (!shadow) return;
    const coreReady = Object.values(state.coreMap).every(Boolean);
    $("runButton").disabled =
      state.running || !state.csvRows.length || !coreReady;
    $("stopButton").disabled = !state.running;
  }

  function log(message, type = "") {
    if (!shadow) return;
    const line = document.createElement("div");
    line.textContent = `[${new Date().toLocaleTimeString("ko-KR", {hour12: false})}] ${message}`;
    if (type) line.className = type;
    $("logBox").appendChild(line);
    $("logBox").scrollTop = $("logBox").scrollHeight;
  }

  function delay(milliseconds) {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  }

  function findElement(selector) {
    if (!selector) return null;
    try {
      return document.querySelector(selector);
    } catch {
      return null;
    }
  }

  async function waitUntilEnabled(selector, timeout = 5000) {
    const deadline = Date.now() + timeout;

    while (Date.now() < deadline) {
      const element = findElement(selector);
      if (element && !element.disabled) return element;
      await delay(100);
    }

    return null;
  }

  function setElementValue(element, value) {
    const text = String(value ?? "");

    if (element instanceof HTMLSelectElement) {
      const option = Array.from(element.options).find(item =>
        item.value === text || item.text.trim() === text.trim()
      );
      if (option) element.value = option.value;
      else element.value = text;
    } else {
      const prototype = element instanceof HTMLTextAreaElement
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
      const setter =
        Object.getOwnPropertyDescriptor(prototype, "value")?.set;

      if (setter) setter.call(element, text);
      else element.value = text;
    }

    element.dispatchEvent(new Event("input", {bubbles: true}));
    element.dispatchEvent(new Event("change", {bubbles: true}));
    element.dispatchEvent(new Event("blur", {bubbles: true}));
  }

  async function inputValue(element, value) {
    highlight(element);
    element.scrollIntoView({block: "center", inline: "nearest"});
    element.focus();
    setElementValue(element, value);
    await delay(250);
  }

  async function clickElement(element) {
    highlight(element);
    element.scrollIntoView({block: "center", inline: "nearest"});
    element.click();
    await delay(350);
  }

  function normalizeValue(value) {
    const raw = String(value ?? "").trim();
    const numeric = raw.replace(/[,\s원₩]/g, "");

    if (/^-?\d+(\.\d+)?$/.test(numeric)) {
      return {kind: "number", value: Number(numeric)};
    }

    return {kind: "text", value: raw};
  }

  function valuesEqual(left, right) {
    const a = normalizeValue(left);
    const b = normalizeValue(right);

    if (a.kind === "number" && b.kind === "number") {
      return a.value === b.value;
    }
    return a.value === b.value;
  }

  async function pauseForMissing(name, item, csvValue) {
    state.pendingItem = {name, item, csvValue};
    $("pauseText").innerHTML =
      `<b>${escapeHtml(name)}</b>의 <b>${escapeHtml(item)}</b> 입력란이 없습니다.<br>` +
      `CSV 금액: <b>${escapeHtml(csvValue)}</b><br>` +
      `사이트에서 항목을 수기로 추가한 뒤 맵핑하거나, 이번 항목을 수기로 입력하십시오.`;
    $("pauseBox").classList.add("show");
    $("runStatus").textContent = "수기입력 대기";
    log(`${name} · ${item}: 신규 항목 또는 입력란 없음 → 정지`, "warn");

    return new Promise(resolve => {
      state.pauseResolver = resolve;
    });
  }

  function resolvePause(action) {
    if (!state.pauseResolver) return;
    const resolve = state.pauseResolver;
    state.pauseResolver = null;
    $("pauseBox").classList.remove("show");
    resolve(action);
  }

  async function runAutomation() {
    if (state.running) return;

    state.running = true;
    state.stopRequested = false;
    $("runStatus").textContent = "실행 중";
    updateButtons();

    try {
      for (const row of state.csvRows) {
        if (state.stopRequested) break;

        const employeeName = row["이름"];
        log(`${employeeName}: 처리 시작`);

        const nameInput = findElement(state.coreMap.nameInput);
        const confirmButton = findElement(state.coreMap.confirmButton);
        const saveButton = findElement(state.coreMap.saveButton);

        if (!nameInput || !confirmButton || !saveButton) {
          throw new Error("이름·확인·저장 맵핑 중 하나를 찾을 수 없습니다.");
        }

        await inputValue(nameInput, employeeName);
        await clickElement(confirmButton);

        const copyButton = await waitUntilEnabled(state.coreMap.copyButton);
        if (!copyButton) {
          throw new Error(`${employeeName}: 전월자료 복사 버튼을 사용할 수 없습니다.`);
        }
        await clickElement(copyButton);

        for (const item of salaryHeaders()) {
          if (state.stopRequested) break;

          let selector = state.salaryMap[item] || "";
          let element = findElement(selector);
          let skipManual = false;

          while (!element) {
            const action = await pauseForMissing(employeeName, item, row[item]);

            if (action === "cancel") {
              state.stopRequested = true;
              break;
            }

            if (action === "manual") {
              skipManual = true;
              log(`${employeeName} · ${item}: 수기입력값 유지`, "warn");
              break;
            }

            selector = state.salaryMap[item] || "";
            element = findElement(selector);

            if (!element) {
              log(`${item}: 맵핑된 입력란을 아직 찾지 못했습니다.`, "warn");
            }
          }

          if (state.stopRequested || skipManual) continue;

          const currentValue = "value" in element
            ? element.value
            : element.textContent;

          if (valuesEqual(currentValue, row[item])) {
            log(`${employeeName} · ${item}: 금액 동일 → 건너뜀`);
          } else {
            await inputValue(element, row[item]);
            log(`${employeeName} · ${item}: CSV 금액 입력`);
          }
        }

        if (state.stopRequested) break;

        await clickElement(saveButton);
        log(`${employeeName}: 저장 버튼 클릭`);
      }

      $("runStatus").textContent =
        state.stopRequested ? "중단됨" : "완료";
      log(state.stopRequested ? "실행 중단" : "전체 실행 완료");
    } catch (error) {
      $("runStatus").textContent = "오류";
      log(error.message, "error");
      alert(error.message);
    } finally {
      state.running = false;
      state.pauseResolver = null;
      state.pendingItem = null;
      $("pauseBox").classList.remove("show");
      updateButtons();
    }
  }

  showPanel();
})();