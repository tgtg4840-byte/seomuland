(() => {
  "use strict";

  if (window.__salaryRpaLoaded) {
    if (typeof window.__salaryRpaShowPanel === "function") {
      window.__salaryRpaShowPanel();
    }
    return;
  }
  window.__salaryRpaLoaded = true;

  const HOST_ID = "__salary_rpa_panel_host__";
  const HIGHLIGHT_CLASS = "__salary_rpa_highlight__";
  const RESERVED_COLUMNS = new Set(["이름"]);

  const state = {
    csvRows: [],
    headers: [],
    fileName: "",
    coreMap: {
      nameInput: "",
      confirmButton: "",
      copyButton: "",
      saveButton: ""
    },
    salaryMap: {},
    mappingTarget: null,
    running: false,
    stopRequested: false,
    pauseResolver: null,
    pendingItem: null,
    skipUnmappedSalary: false,
    customActions: [],
    customActionCounter: 1
  };

  let host = null;
  let shadow = null;

  function createPanel() {
    host = document.getElementById(HOST_ID);
    if (host) {
      host.style.display = "block";
      return;
    }

    host = document.createElement("div");
    host.id = HOST_ID;
    host.style.position = "fixed";
    host.style.top = "12px";
    host.style.right = "12px";
    host.style.zIndex = "2147483647";
    host.style.width = "520px";
    host.style.maxHeight = "calc(100vh - 24px)";
    host.style.fontFamily = '"Malgun Gothic", Arial, sans-serif';
    document.documentElement.appendChild(host);

    shadow = host.attachShadow({mode: "open"});
    shadow.innerHTML = `
      <style>
        *{box-sizing:border-box}
        .panel{background:#fff;border:1px solid #cfd9e2;border-radius:12px;
          box-shadow:0 14px 38px rgba(0,0,0,.22);overflow:hidden;color:#1d2935}
        .header{display:flex;align-items:center;justify-content:space-between;
          padding:11px 13px;background:#174f80;color:#fff}
        .header strong{font-size:15px}.close{border:0;background:transparent;color:#fff;
          font-size:20px;cursor:pointer;line-height:1}
        .body{padding:11px;max-height:calc(100vh - 78px);overflow:auto;background:#f5f8fa}
        .section{background:#fff;border:1px solid #d8e1e9;border-radius:9px;
          margin-bottom:9px;overflow:hidden}
        .title{padding:9px 10px;background:#f8fafc;border-bottom:1px solid #e0e7ed;
          font-size:12px;font-weight:700}
        .content{padding:10px}.row{display:flex;gap:7px;align-items:center;flex-wrap:wrap}
        button{font:inherit;border:1px solid #c9d5df;background:#fff;border-radius:7px;
          padding:7px 9px;font-size:12px;font-weight:700;cursor:pointer}
        button.primary{background:#246aa8;color:#fff;border-color:#246aa8}
        button.success{background:#18794e;color:#fff;border-color:#18794e}
        button.warn{background:#fff7e9;color:#9a6200;border-color:#e5c58f}
        button.danger{background:#fff1ef;color:#b42318;border-color:#efc1bb}
        button:disabled{opacity:.45;cursor:not-allowed}
        input[type=file]{width:100%;font-size:12px}
        input[type=text],select{font:inherit;border:1px solid #c9d5df;border-radius:7px;
          padding:7px 8px;font-size:12px;background:#fff;min-width:0}
        .meta{font-size:11px;color:#687684;margin-top:6px}
        .custom-box{padding:10px;border-top:1px solid #e0e7ed;background:#fbfcfd}
        .custom-title{font-size:11px;font-weight:700;margin-bottom:7px;color:#4f5d69}
        .custom-form{display:grid;grid-template-columns:110px 1fr;gap:6px}
        .custom-form select,.custom-form input{width:100%}
        .custom-form .full{grid-column:1 / -1}
        .delete-button{padding:6px 7px!important}
        table{width:100%;border-collapse:collapse}
        th,td{padding:7px;border-bottom:1px solid #e8edf2;text-align:left;font-size:11px}
        th{background:#f7f9fb;color:#5d6974;position:sticky;top:0}
        .table-wrap{max-height:240px;overflow:auto}
        .mapped{color:#18794e;font-weight:700}.missing{color:#b42318;font-weight:700}
        .log{height:145px;overflow:auto;background:#17211b;color:#d4e7d8;
          border-radius:7px;padding:8px;font:11px/1.55 Consolas,monospace}
        .log div::before{content:"› ";color:#7cc490}
        .log .warn{color:#ffd17a}.log .error{color:#ffaaa4}
        .pause{display:none;padding:9px;border:1px solid #e3bd78;background:#fff8ea;
          border-radius:8px;margin-top:8px}
        .pause.show{display:block}.pause p{font-size:11px;line-height:1.5;margin:0 0 8px}
        .status{font-size:11px;color:#687684;margin-left:auto}
        .guide{font-size:11px;color:#9a6200;font-weight:700;margin-top:7px}
        .option{display:flex;align-items:flex-start;gap:7px;margin-top:10px;
          padding:8px;background:#f8fafc;border:1px solid #e2e8ee;border-radius:7px}
        .option input{margin-top:2px}
        .option label{font-size:11px;line-height:1.45;color:#4f5d69;cursor:pointer}
      </style>

      <div class="panel">
        <div class="header">
          <strong>급여입력 RPA</strong>
          <button class="close" id="closePanel" title="닫기">×</button>
        </div>

        <div class="body">
          <section class="section">
            <div class="title">1. CSV 불러오기</div>
            <div class="content">
              <input id="csvFile" type="file" accept=".csv,text/csv">
              <div class="meta" id="csvMeta">CSV 미선택</div>
            </div>
          </section>

          <section class="section">
            <div class="title">2. 입력란·버튼 맵핑</div>
            <div class="table-wrap">
              <table>
                <thead><tr><th>항목</th><th>동작</th><th>상태</th><th></th></tr></thead>
                <tbody id="mappingBody"></tbody>
              </table>
            </div>
            <div class="custom-box">
              <div class="custom-title">사용자 정의 동작 추가</div>
              <div class="custom-form">
                <select id="customActionType">
                  <option value="input">입력</option>
                  <option value="click">클릭</option>
                </select>
                <input id="customActionLabel" type="text" placeholder="동작명">

                <select id="customCsvHeader"></select>
                <select id="customActionPosition">
                  <option value="beforeName">이름 입력 전</option>
                  <option value="afterName">이름 입력 후 · 확인 전</option>
                  <option value="afterConfirm">확인 후 · 전월복사 전</option>
                  <option value="afterCopy">전월복사 후 · 급여입력 전</option>
                  <option value="afterSalary" selected>급여입력 후 · 저장 전</option>
                  <option value="afterSave">저장 후</option>
                </select>

                <button class="primary full" id="addCustomAction">사용자 정의 동작 추가</button>
              </div>
              <div class="meta">
                실행 위치별로 추가한 순서대로 동작합니다.
              </div>
            </div>
            <div class="content">
              <div class="guide" id="mappingGuide">맵핑할 항목의 버튼을 누르십시오.</div>
            </div>
          </section>

          <section class="section">
            <div class="title">3. 실행</div>
            <div class="content">
              <div class="row">
                <button class="success" id="runButton" disabled>자동입력 시작</button>
                <button class="danger" id="stopButton" disabled>중단</button>
                <span class="status" id="runStatus">대기</span>
              </div>

              <div class="option">
                <input id="skipUnmappedSalary" type="checkbox">
                <label for="skipUnmappedSalary">
                  미매핑 급여항목·사용자 동작은 건너뛰고 계속 진행
                </label>
              </div>

              <div class="pause" id="pauseBox">
                <p id="pauseText"></p>
                <div class="row">
                  <button class="primary" id="mapMissingButton">신규 항목 맵핑</button>
                  <button class="warn" id="manualContinueButton">수기입력 후 계속</button>
                  <button class="danger" id="cancelButton">중단</button>
                </div>
              </div>
            </div>
          </section>

          <section class="section">
            <div class="title">로그</div>
            <div class="content">
              <div class="log" id="logBox"></div>
            </div>
          </section>
        </div>
      </div>
    `;

    bindPanelEvents();
    renderMappings();
    updateButtons();
    log("RPA 패널 준비 완료");
  }

  function $(id) {
    return shadow.getElementById(id);
  }

  function showPanel() {
    createPanel();
    host.style.display = "block";
  }
  window.__salaryRpaShowPanel = showPanel;

  function bindPanelEvents() {
    $("closePanel").addEventListener("click", () => {
      host.style.display = "none";
    });

    $("csvFile").addEventListener("change", event => {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = () => {
        try {
          const {text, encoding} = decodeCsvBuffer(reader.result);
          loadCsv(text, file.name);
          log(`문자 인코딩 감지: ${encoding}`);
        } catch (error) {
          alert(error.message);
          log(error.message, "error");
        }
      };
      reader.readAsArrayBuffer(file);
    });

    $("customActionType").addEventListener("change", updateCustomActionForm);
    $("addCustomAction").addEventListener("click", addCustomAction);

    $("runButton").addEventListener("click", runAutomation);

    $("skipUnmappedSalary").addEventListener("change", event => {
      state.skipUnmappedSalary = Boolean(event.target.checked);
      log(state.skipUnmappedSalary
        ? "미매핑 급여항목 건너뛰기 옵션 사용"
        : "미매핑 급여항목에서 정지하도록 변경");
    });

    $("stopButton").addEventListener("click", () => {
      state.stopRequested = true;
      resolvePause("cancel");
    });

    $("mapMissingButton").addEventListener("click", () => {
      if (!state.pendingItem) return;
      beginMapping({
        kind: state.pendingItem.mappingKind,
        key: state.pendingItem.key,
        resumeAfterMapping: true
      });
    });

    $("manualContinueButton").addEventListener("click", () => {
      resolvePause("manual");
    });

    $("cancelButton").addEventListener("click", () => {
      resolvePause("cancel");
    });

    document.addEventListener("click", captureMappedElement, true);
    refreshCustomColumnOptions();
    updateCustomActionForm();
  }

  function decodeCsvBuffer(buffer) {
    if (!(buffer instanceof ArrayBuffer)) {
      throw new Error("CSV 파일을 읽지 못했습니다.");
    }

    const bytes = new Uint8Array(buffer);

    // UTF-8 BOM
    if (bytes.length >= 3 &&
        bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) {
      return {
        text: new TextDecoder("utf-8").decode(bytes.subarray(3)),
        encoding: "UTF-8 BOM"
      };
    }

    // UTF-16 LE BOM
    if (bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xFE) {
      return {
        text: new TextDecoder("utf-16le").decode(bytes.subarray(2)),
        encoding: "UTF-16 LE"
      };
    }

    // UTF-16 BE BOM
    if (bytes.length >= 2 && bytes[0] === 0xFE && bytes[1] === 0xFF) {
      return {
        text: new TextDecoder("utf-16be").decode(bytes.subarray(2)),
        encoding: "UTF-16 BE"
      };
    }

    // BOM이 없으면 우선 엄격한 UTF-8 판독을 시도합니다.
    try {
      const text = new TextDecoder("utf-8", {fatal: true}).decode(bytes);
      return {text, encoding: "UTF-8"};
    } catch {
      // 국내 Excel CSV에서 흔한 CP949는 브라우저의 euc-kr 디코더로 처리합니다.
      try {
        const text = new TextDecoder("euc-kr", {fatal: true}).decode(bytes);
        return {text, encoding: "CP949 / EUC-KR"};
      } catch {
        throw new Error(
          "CSV 문자 인코딩을 판별하지 못했습니다. " +
          "Excel에서 'CSV UTF-8(쉼표로 분리)' 형식으로 다시 저장하십시오."
        );
      }
    }
  }

  function parseCsv(text) {
    text = text.replace(/^\uFEFF/, "");
    const matrix = [];
    let row = [];
    let cell = "";
    let quoted = false;

    for (let i = 0; i < text.length; i++) {
      const ch = text[i];

      if (quoted) {
        if (ch === '"' && text[i + 1] === '"') {
          cell += '"';
          i++;
        } else if (ch === '"') {
          quoted = false;
        } else {
          cell += ch;
        }
      } else {
        if (ch === '"') {
          quoted = true;
        } else if (ch === ",") {
          row.push(cell.trim());
          cell = "";
        } else if (ch === "\n") {
          row.push(cell.trim());
          cell = "";
          if (row.some(value => value !== "")) matrix.push(row);
          row = [];
        } else if (ch !== "\r") {
          cell += ch;
        }
      }
    }

    if (cell.length || row.length) {
      row.push(cell.trim());
      if (row.some(value => value !== "")) matrix.push(row);
    }

    return matrix;
  }

  function loadCsv(text, fileName) {
    const matrix = parseCsv(text);
    if (matrix.length < 2) {
      throw new Error("CSV에 입력할 데이터가 없습니다.");
    }

    const rawHeaders = matrix[0];
    if (!rawHeaders.length) {
      throw new Error("CSV 헤더를 확인할 수 없습니다.");
    }

    // 첫 번째 열은 헤더명과 관계없이 이름 열로 처리합니다.
    const headers = [...rawHeaders];
    headers[0] = "이름";

    state.headers = headers;

    // 첫 행은 헤더이므로 제외하고 두 번째 행부터 입력 대상으로 사용합니다.
    state.csvRows = matrix.slice(1).map(cells => {
      const row = {};
      headers.forEach((header, index) => {
        row[header] = cells[index] ?? "";
      });
      return row;
    });
    state.fileName = fileName;

    salaryHeaders().forEach(header => {
      if (!(header in state.salaryMap)) {
        state.salaryMap[header] = "";
      }
    });

    $("csvMeta").textContent =
      `${fileName} · ${state.csvRows.length}명 · 급여항목 ${salaryHeaders().length}개`;

    refreshCustomColumnOptions();
    renderMappings();
    updateButtons();
    log(`CSV 불러오기 완료: ${fileName}`);
  }

  function salaryHeaders() {
    // 첫 번째 열은 항상 이름 열이므로 급여항목 맵핑 대상에서 제외합니다.
    return state.headers.slice(1);
  }

  function findCustomAction(id) {
    return state.customActions.find(action => action.id === Number(id)) || null;
  }

  function refreshCustomColumnOptions() {
    if (!shadow) return;

    const select = $("customCsvHeader");
    const previous = select.value;
    select.innerHTML = "";

    const headers = salaryHeaders();
    if (!headers.length) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "CSV 열 없음";
      select.appendChild(option);
    } else {
      headers.forEach(header => {
        const option = document.createElement("option");
        option.value = header;
        option.textContent = header;
        select.appendChild(option);
      });

      if (headers.includes(previous)) {
        select.value = previous;
      }
    }

    updateCustomActionForm();
  }

  function updateCustomActionForm() {
    if (!shadow) return;
    const isClick = $("customActionType").value === "click";
    $("customCsvHeader").disabled = isClick || !salaryHeaders().length;
    $("customCsvHeader").style.opacity = isClick ? ".45" : "1";
  }

  function customPositionLabel(position) {
    const labels = {
      beforeName: "이름 입력 전",
      afterName: "이름 입력 후 · 확인 전",
      afterConfirm: "확인 후 · 전월복사 전",
      afterCopy: "전월복사 후 · 급여입력 전",
      afterSalary: "급여입력 후 · 저장 전",
      afterSave: "저장 후"
    };
    return labels[position] || position;
  }

  function addCustomAction() {
    const type = $("customActionType").value;
    const csvHeader = type === "input" ? $("customCsvHeader").value : "";
    const position = $("customActionPosition").value;
    const enteredLabel = $("customActionLabel").value.trim();

    if (type === "input" && !csvHeader) {
      alert("입력 동작에 사용할 CSV 열을 선택하십시오.");
      return;
    }

    const number = state.customActionCounter++;
    const label = enteredLabel ||
      (type === "input" ? `추가 입력 ${number}` : `추가 클릭 ${number}`);

    state.customActions.push({
      id: number,
      type,
      label,
      csvHeader,
      position,
      selector: ""
    });

    $("customActionLabel").value = "";
    renderMappings();
    log(
      `${label}: 사용자 정의 ${type === "input" ? "입력" : "클릭"} 동작 추가 ` +
      `(${customPositionLabel(position)})`
    );
  }

  function deleteCustomAction(id) {
    const action = findCustomAction(id);
    if (!action) return;

    state.customActions = state.customActions.filter(item => item.id !== action.id);

    if (state.mappingTarget?.kind === "custom" &&
        Number(state.mappingTarget.key) === action.id) {
      state.mappingTarget = null;
      $("mappingGuide").textContent = "맵핑할 항목의 버튼을 누르십시오.";
    }

    renderMappings();
    log(`${action.label}: 사용자 정의 동작 삭제`, "warn");
  }

  function mappingRows() {
    const rows = [
      {kind: "core", key: "nameInput", label: "이름 입력란", action: "입력",
        selector: state.coreMap.nameInput},
      {kind: "core", key: "confirmButton", label: "확인 버튼", action: "클릭",
        selector: state.coreMap.confirmButton},
      {kind: "core", key: "copyButton", label: "전월자료 복사 버튼", action: "클릭",
        selector: state.coreMap.copyButton},
      {kind: "core", key: "saveButton", label: "저장 버튼", action: "클릭",
        selector: state.coreMap.saveButton}
    ];

    salaryHeaders().forEach(header => {
      rows.push({
        kind: "salary",
        key: header,
        label: header,
        action: "입력",
        selector: state.salaryMap[header] || "",
        deletable: false
      });
    });

    state.customActions.forEach(action => {
      rows.push({
        kind: "custom",
        key: action.id,
        label: action.label,
        action: action.type === "input"
          ? `입력 · ${action.csvHeader} · ${customPositionLabel(action.position)}`
          : `클릭 · ${customPositionLabel(action.position)}`,
        selector: action.selector,
        deletable: true
      });
    });

    return rows;
  }

  function renderMappings() {
    const body = $("mappingBody");
    body.innerHTML = "";

    mappingRows().forEach(item => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${escapeHtml(item.label)}</td>
        <td>${escapeHtml(item.action)}</td>
        <td class="${item.selector ? "mapped" : "missing"}">
          ${item.selector ? "완료" : "미맵핑"}
        </td>
        <td>
          <button class="map-button">맵핑</button>
          ${item.deletable
            ? '<button class="danger delete-button">삭제</button>'
            : ''}
        </td>
      `;

      tr.querySelector(".map-button").addEventListener("click", () => {
        beginMapping({
          kind: item.kind,
          key: item.key,
          resumeAfterMapping: false
        });
      });

      const deleteButton = tr.querySelector(".delete-button");
      if (deleteButton) {
        deleteButton.addEventListener("click", () => deleteCustomAction(item.key));
      }

      body.appendChild(tr);
    });
  }

  function beginMapping(target) {
    state.mappingTarget = target;

    let label = target.key;
    if (target.kind === "core") {
      label = mappingRows()
        .find(item => item.kind === "core" && item.key === target.key)?.label;
    } else if (target.kind === "custom") {
      label = findCustomAction(target.key)?.label;
    }

    $("mappingGuide").textContent =
      `${label || target.key}: 실제 사이트의 대응 입력란 또는 버튼을 클릭하십시오.`;
    log(`${label || target.key} 맵핑 대기`, "warn");
  }

  function captureMappedElement(event) {
    if (!state.mappingTarget) return;

    const path = event.composedPath ? event.composedPath() : [];
    if (path.includes(host)) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    let element = event.target;
    if (element && typeof element.closest === "function") {
      element = element.closest("input,textarea,select,button,[role='button']") || element;
    }

    const selector = makeSelector(element);
    const target = state.mappingTarget;
    state.mappingTarget = null;

    let mappedLabel = target.key;

    if (target.kind === "core") {
      state.coreMap[target.key] = selector;
    } else if (target.kind === "salary") {
      state.salaryMap[target.key] = selector;
    } else if (target.kind === "custom") {
      const action = findCustomAction(target.key);
      if (!action) {
        throw new Error("삭제된 사용자 정의 동작입니다.");
      }
      action.selector = selector;
      mappedLabel = action.label;
    }

    highlight(element);
    $("mappingGuide").textContent = `${mappedLabel} 맵핑 완료`;
    log(`${mappedLabel} → ${selector}`);

    renderMappings();
    updateButtons();

    if (target.resumeAfterMapping) {
      resolvePause("mapped");
    }
  }

  function makeSelector(element) {
    if (!(element instanceof Element)) {
      throw new Error("선택한 화면 요소를 맵핑할 수 없습니다.");
    }

    if (element.id) {
      const candidate = `#${cssEscape(element.id)}`;
      if (document.querySelectorAll(candidate).length === 1) return candidate;
    }

    if (element.getAttribute("name")) {
      const name = element.getAttribute("name");
      const candidate =
        `${element.tagName.toLowerCase()}[name="${escapeAttribute(name)}"]`;
      if (document.querySelectorAll(candidate).length === 1) return candidate;
    }

    const dataAttributes = ["data-pay-item", "data-field", "data-name"];
    for (const attribute of dataAttributes) {
      const value = element.getAttribute(attribute);
      if (value) {
        const candidate = `[${attribute}="${escapeAttribute(value)}"]`;
        if (document.querySelectorAll(candidate).length === 1) return candidate;
      }
    }

    const parts = [];
    let current = element;

    while (current && current.nodeType === Node.ELEMENT_NODE &&
           current !== document.documentElement) {
      let part = current.tagName.toLowerCase();
      const parent = current.parentElement;

      if (parent) {
        const sameTags = Array.from(parent.children)
          .filter(child => child.tagName === current.tagName);
        if (sameTags.length > 1) {
          part += `:nth-of-type(${sameTags.indexOf(current) + 1})`;
        }
      }

      parts.unshift(part);
      const candidate = parts.join(" > ");
      if (document.querySelectorAll(candidate).length === 1) return candidate;
      current = parent;
    }

    return parts.join(" > ");
  }

  function cssEscape(value) {
    if (window.CSS && typeof CSS.escape === "function") return CSS.escape(value);
    return String(value).replace(/([^\w-])/g, "\\$1");
  }

  function escapeAttribute(value) {
    return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;",
      '"': "&quot;", "'": "&#039;"
    }[ch]));
  }

  function highlight(element) {
    if (!(element instanceof Element)) return;
    element.classList.add(HIGHLIGHT_CLASS);

    if (!document.getElementById("__salary_rpa_highlight_style__")) {
      const style = document.createElement("style");
      style.id = "__salary_rpa_highlight_style__";
      style.textContent =
        `.${HIGHLIGHT_CLASS}{outline:4px solid #f0a229!important;outline-offset:2px!important}`;
      document.documentElement.appendChild(style);
    }

    setTimeout(() => element.classList.remove(HIGHLIGHT_CLASS), 800);
  }

  function updateButtons() {
    if (!shadow) return;
    const coreReady = Object.values(state.coreMap).every(Boolean);
    $("runButton").disabled =
      state.running || !state.csvRows.length || !coreReady;
    $("stopButton").disabled = !state.running;
  }

  function log(message, type = "") {
    if (!shadow) return;
    const line = document.createElement("div");
    line.textContent = `[${new Date().toLocaleTimeString("ko-KR", {hour12: false})}] ${message}`;
    if (type) line.className = type;
    $("logBox").appendChild(line);
    $("logBox").scrollTop = $("logBox").scrollHeight;
  }

  function delay(milliseconds) {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  }

  function findElement(selector) {
    if (!selector) return null;
    try {
      return document.querySelector(selector);
    } catch {
      return null;
    }
  }

  async function waitUntilEnabled(selector, timeout = 5000) {
    const deadline = Date.now() + timeout;

    while (Date.now() < deadline) {
      const element = findElement(selector);
      if (element && !element.disabled) return element;
      await delay(100);
    }

    return null;
  }

  function setElementValue(element, value) {
    const text = String(value ?? "");

    if (element instanceof HTMLSelectElement) {
      const option = Array.from(element.options).find(item =>
        item.value === text || item.text.trim() === text.trim()
      );
      if (option) element.value = option.value;
      else element.value = text;
    } else {
      const prototype = element instanceof HTMLTextAreaElement
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
      const setter =
        Object.getOwnPropertyDescriptor(prototype, "value")?.set;

      if (setter) setter.call(element, text);
      else element.value = text;
    }

    element.dispatchEvent(new Event("input", {bubbles: true}));
    element.dispatchEvent(new Event("change", {bubbles: true}));
    element.dispatchEvent(new Event("blur", {bubbles: true}));
  }

  async function inputValue(element, value) {
    highlight(element);
    element.scrollIntoView({block: "center", inline: "nearest"});
    element.focus();
    setElementValue(element, value);
    await delay(250);
  }

  async function clickElement(element) {
    highlight(element);
    element.scrollIntoView({block: "center", inline: "nearest"});
    element.click();
    await delay(350);
  }

  function normalizeValue(value) {
    const raw = String(value ?? "").trim();
    const numeric = raw.replace(/[,\s원₩]/g, "");

    if (/^-?\d+(\.\d+)?$/.test(numeric)) {
      return {kind: "number", value: Number(numeric)};
    }

    return {kind: "text", value: raw};
  }

  function valuesEqual(left, right) {
    const a = normalizeValue(left);
    const b = normalizeValue(right);

    if (a.kind === "number" && b.kind === "number") {
      return a.value === b.value;
    }
    return a.value === b.value;
  }

  async function pauseForMissingAction({
    name, mappingKind, key, label, value, actionType
  }) {
    state.pendingItem = {
      name,
      mappingKind,
      key,
      label,
      value,
      actionType
    };

    const valueLine = actionType === "input"
      ? `CSV 값: <b>${escapeHtml(value)}</b><br>`
      : "버튼을 직접 클릭한 뒤 계속할 수 있습니다.<br>";

    $("pauseText").innerHTML =
      `<b>${escapeHtml(name)}</b>의 <b>${escapeHtml(label)}</b> ` +
      `${actionType === "input" ? "입력란" : "버튼"}을 찾지 못했습니다.<br>` +
      valueLine +
      `새로 맵핑하거나, 수기로 처리한 뒤 계속하십시오.`;

    $("pauseBox").classList.add("show");
    $("runStatus").textContent = "수기처리 대기";
    log(`${name} · ${label}: 미맵핑 → 정지`, "warn");

    return new Promise(resolve => {
      state.pauseResolver = resolve;
    });
  }

  function resolvePause(action) {
    if (!state.pauseResolver) return;
    const resolve = state.pauseResolver;
    state.pauseResolver = null;
    $("pauseBox").classList.remove("show");
    resolve(action);
  }

  async function runCustomActionsAt(position, row, employeeName) {
    const actions = state.customActions.filter(
      customAction => customAction.position === position
    );

    for (const customAction of actions) {
      if (state.stopRequested) break;

      if (customAction.type === "input" &&
          !Object.prototype.hasOwnProperty.call(row, customAction.csvHeader)) {
        log(
          `${employeeName} · ${customAction.label}: ` +
          `CSV 열 '${customAction.csvHeader}' 없음 → 건너뜀`,
          "warn"
        );
        continue;
      }

      let element = findElement(customAction.selector);
      let skipCustom = false;

      while (!element) {
        if (state.skipUnmappedSalary) {
          skipCustom = true;
          log(
            `${employeeName} · ${customAction.label}: ` +
            `미매핑 사용자 동작 → 건너뜀`,
            "warn"
          );
          break;
        }

        const decision = await pauseForMissingAction({
          name: employeeName,
          mappingKind: "custom",
          key: customAction.id,
          label: customAction.label,
          value: customAction.type === "input"
            ? row[customAction.csvHeader]
            : "",
          actionType: customAction.type
        });

        if (decision === "cancel") {
          state.stopRequested = true;
          break;
        }

        if (decision === "manual") {
          skipCustom = true;
          log(
            `${employeeName} · ${customAction.label}: 수기처리 후 계속`,
            "warn"
          );
          break;
        }

        element = findElement(customAction.selector);
        if (!element) {
          log(
            `${customAction.label}: 맵핑된 화면 요소를 아직 찾지 못했습니다.`,
            "warn"
          );
        }
      }

      if (state.stopRequested || skipCustom) continue;

      if (customAction.type === "click") {
        await clickElement(element);
        log(
          `${employeeName} · ${customAction.label}: 클릭 ` +
          `(${customPositionLabel(position)})`
        );
        continue;
      }

      const targetValue = row[customAction.csvHeader];
      const currentValue = "value" in element
        ? element.value
        : element.textContent;

      if (valuesEqual(currentValue, targetValue)) {
        log(`${employeeName} · ${customAction.label}: 값 동일 → 건너뜀`);
      } else {
        await inputValue(element, targetValue);
        log(
          `${employeeName} · ${customAction.label}: CSV 값 입력 ` +
          `(${customPositionLabel(position)})`
        );
      }
    }
  }

  async function runAutomation() {
    if (state.running) return;

    state.running = true;
    state.stopRequested = false;
    $("runStatus").textContent = "실행 중";
    updateButtons();

    try {
      for (const row of state.csvRows) {
        if (state.stopRequested) break;

        const employeeName = row["이름"];
        log(`${employeeName}: 처리 시작`);

        const nameInput = findElement(state.coreMap.nameInput);
        const confirmButton = findElement(state.coreMap.confirmButton);
        const saveButton = findElement(state.coreMap.saveButton);

        if (!nameInput || !confirmButton || !saveButton) {
          throw new Error("이름·확인·저장 맵핑 중 하나를 찾을 수 없습니다.");
        }

        await runCustomActionsAt("beforeName", row, employeeName);
        if (state.stopRequested) break;

        await inputValue(nameInput, employeeName);

        await runCustomActionsAt("afterName", row, employeeName);
        if (state.stopRequested) break;

        await clickElement(confirmButton);

        await runCustomActionsAt("afterConfirm", row, employeeName);
        if (state.stopRequested) break;

        const copyButton = await waitUntilEnabled(state.coreMap.copyButton);
        if (!copyButton) {
          throw new Error(
            `${employeeName}: 전월자료 복사 버튼을 사용할 수 없습니다.`
          );
        }
        await clickElement(copyButton);

        await runCustomActionsAt("afterCopy", row, employeeName);
        if (state.stopRequested) break;

        for (const item of salaryHeaders()) {
          if (state.stopRequested) break;

          let selector = state.salaryMap[item] || "";
          let element = findElement(selector);
          let skipManual = false;

          while (!element) {
            if (state.skipUnmappedSalary) {
              skipManual = true;
              log(`${employeeName} · ${item}: 미매핑 항목 → 건너뜀`, "warn");
              break;
            }

            const action = await pauseForMissingAction({
              name: employeeName,
              mappingKind: "salary",
              key: item,
              label: item,
              value: row[item],
              actionType: "input"
            });

            if (action === "cancel") {
              state.stopRequested = true;
              break;
            }

            if (action === "manual") {
              skipManual = true;
              log(`${employeeName} · ${item}: 수기입력값 유지`, "warn");
              break;
            }

            selector = state.salaryMap[item] || "";
            element = findElement(selector);

            if (!element) {
              log(`${item}: 맵핑된 입력란을 아직 찾지 못했습니다.`, "warn");
            }
          }

          if (state.stopRequested || skipManual) continue;

          const currentValue = "value" in element
            ? element.value
            : element.textContent;

          if (valuesEqual(currentValue, row[item])) {
            log(`${employeeName} · ${item}: 금액 동일 → 건너뜀`);
          } else {
            await inputValue(element, row[item]);
            log(`${employeeName} · ${item}: CSV 금액 입력`);
          }
        }

        if (state.stopRequested) break;

        await runCustomActionsAt("afterSalary", row, employeeName);
        if (state.stopRequested) break;

        await clickElement(saveButton);
        log(`${employeeName}: 저장 버튼 클릭`);

        await runCustomActionsAt("afterSave", row, employeeName);
        if (state.stopRequested) break;
      }

      $("runStatus").textContent =
        state.stopRequested ? "중단됨" : "완료";
      log(state.stopRequested ? "실행 중단" : "전체 실행 완료");
    } catch (error) {
      $("runStatus").textContent = "오류";
      log(error.message, "error");
      alert(error.message);
    } finally {
      state.running = false;
      state.pauseResolver = null;
      state.pendingItem = null;
      $("pauseBox").classList.remove("show");
      updateButtons();
    }
  }

  showPanel();
})();