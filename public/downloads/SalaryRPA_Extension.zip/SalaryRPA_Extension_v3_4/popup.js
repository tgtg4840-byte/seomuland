"use strict";

document.getElementById("openPanel").addEventListener("click", async () => {
  const errorBox = document.getElementById("error");
  errorBox.textContent = "";

  try {
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    if (!tab || !tab.id) {
      throw new Error("현재 탭을 확인할 수 없습니다.");
    }

    await chrome.scripting.executeScript({
      target: {tabId: tab.id},
      files: ["content.js"]
    });

    window.close();
  } catch (error) {
    errorBox.textContent =
      "이 페이지에서는 실행할 수 없습니다. 일반 웹사이트 탭에서 다시 시도하십시오.";
    console.error(error);
  }
});